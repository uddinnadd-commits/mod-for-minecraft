package com.sorrowed.worldgen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * One generator, two worlds.
 *
 * "unfinished": chunk-aligned pieces floating in nothing. A big hub platform around the origin,
 * tall 16x16 monoliths, flat slabs, and very long 16-wide ribbons (10 chunks per piece) running
 * along X and Z at different heights. Everything between them is void.
 *
 * "hallway": a sealed, carpeted, yellow-walled maze of rooms. Every 16x16 chunk is a room with
 * walls on its west/north edges that may or may not have a doorway. One room in seventeen is a
 * living room with a television showing static.
 *
 * "drowned": a sea 100 blocks deep with a rolling seabed, deep trenches, and the occasional
 * rock spire breaking the surface.
 *
 * "backup": rolling, perfectly smooth meadow. Every chunk has the same single tree at its
 * centre and flowers on a rigid grid.
 */
public class LiminalGenerator extends ChunkGenerator {
    public static final Codec<LiminalGenerator> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.getBiomeSource()),
            Codec.STRING.fieldOf("mode").forGetter(g -> g.mode)
    ).apply(inst, inst.stable(LiminalGenerator::new)));

    public static final int MIN_Y = -64;
    public static final int HEIGHT = 384;
    /** Top block of the hub platform in the Unfinished; you stand at 65. */
    public static final int PLATFORM_TOP = 64;
    public static final int HALL_FLOOR = 64;
    public static final int HALL_CEIL = 73;

    private final String mode;

    public LiminalGenerator(BiomeSource source, String mode) {
        super(source);
        this.mode = mode;
    }

    public static final int DROWN_SEA = 40;

    private boolean hallway() {
        return "hallway".equals(mode);
    }

    private boolean drowned() {
        return "drowned".equals(mode);
    }

    private boolean backup() {
        return "backup".equals(mode);
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public void applyCarvers(WorldGenRegion region, long seed, RandomState random, BiomeManager biomes,
                             StructureManager structures, ChunkAccess chunk, GenerationStep.Carving step) {
    }

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager structures, RandomState random, ChunkAccess chunk) {
    }

    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {
    }

    @Override
    public int getGenDepth() {
        return HEIGHT;
    }

    @Override
    public int getSeaLevel() {
        return drowned() ? DROWN_SEA : -63;
    }

    @Override
    public int getMinY() {
        return MIN_Y;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState random,
                                                        StructureManager structures, ChunkAccess chunk) {
        Heightmap oceanFloor = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.OCEAN_FLOOR_WG);
        Heightmap surface = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.WORLD_SURFACE_WG);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = minX + lx;
                int z = minZ + lz;
                int lo;
                int hi;
                if (hallway()) {
                    lo = MIN_Y;
                    hi = HALL_CEIL;
                } else if (drowned()) {
                    lo = MIN_Y;
                    hi = Math.max(drownedFloor(x, z), DROWN_SEA);
                } else if (backup()) {
                    lo = MIN_Y;
                    hi = backupHeight(x, z) + 7;
                } else {
                    Span span = unfinishedSpan(x, z);
                    if (span == null) continue;
                    lo = span.bottom();
                    hi = span.top();
                }
                for (int y = lo; y <= hi; y++) {
                    BlockState state = stateAt(x, y, z);
                    if (state == null || state.isAir()) continue;
                    chunk.setBlockState(pos.set(x, y, z), state, false);
                    oceanFloor.update(lx, y, lz, state);
                    surface.update(lx, y, lz, state);
                }
            }
        }
        return CompletableFuture.completedFuture(chunk);
    }

    private int topAt(int x, int z) {
        if (hallway()) return HALL_CEIL;
        if (drowned()) return Math.max(drownedFloor(x, z), DROWN_SEA);
        if (backup()) return backupHeight(x, z);
        Span span = unfinishedSpan(x, z);
        return span == null ? MIN_Y - 1 : span.top();
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState random) {
        return Math.max(level.getMinBuildHeight(), topAt(x, z) + 1);
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState random) {
        BlockState[] states = new BlockState[level.getHeight()];
        for (int i = 0; i < states.length; i++) {
            BlockState s = stateAt(x, level.getMinBuildHeight() + i, z);
            states[i] = s == null ? Blocks.AIR.defaultBlockState() : s;
        }
        return new NoiseColumn(level.getMinBuildHeight(), states);
    }

    @Override
    public void addDebugScreenInfo(List<String> info, RandomState random, BlockPos pos) {
    }

    // ------------------------------------------------------------------ blocks

    private BlockState stateAt(int x, int y, int z) {
        if (hallway()) return hallwayState(x, y, z);
        if (drowned()) return drownedState(x, y, z);
        if (backup()) return backupState(x, y, z);
        return unfinishedState(x, y, z);
    }

    private record Span(int bottom, int top, int palette) {}

    private static long mix(long a, long b, long c) {
        long h = a * 0x9E3779B97F4A7C15L ^ b * 0xC2B2AE3D27D4EB4FL ^ c * 0x165667B19E3779F9L;
        h ^= h >>> 32;
        h *= 0xD6E8FEB86659FD93L;
        h ^= h >>> 32;
        return h;
    }

    private static Span unfinishedSpan(int x, int z) {
        int cx = x >> 4;
        int cz = z >> 4;

        // The hub: a 7x5 chunk platform around the origin. The gates stand here.
        if (cx >= -3 && cx <= 3 && cz >= -2 && cz <= 2) {
            return new Span(PLATFORM_TOP - 8, PLATFORM_TOP, 0);
        }

        long h = mix(cx, cz, 1);
        int palette = (int) ((h >>> 40) % 3);

        // Monoliths: a whole chunk standing on end, up to y 220.
        if ((h & 15) == 0) {
            int top = 90 + (int) ((h >>> 8) & 127);
            return new Span(-40, top, palette);
        }

        // Long ribbons along X: 16 wide, 160 long, gently waving.
        long rowH = mix(cz, 77, 2);
        if ((rowH & 3) == 0) {
            long segH = mix(Math.floorDiv(cx, 10), cz, 3);
            if ((segH & 3) != 0) {
                int base = 30 + (int) ((rowH >>> 8) & 63);
                int top = base + (int) Math.round(5.0D * Math.sin(x / 37.0D + (rowH & 255)));
                return new Span(top - 3, top, (int) ((segH >>> 40) % 3));
            }
        }

        // Long ribbons along Z.
        long colH = mix(cx, 88, 4);
        if ((colH & 3) == 0) {
            long segH = mix(cx, Math.floorDiv(cz, 10), 5);
            if ((segH & 3) != 0) {
                int base = 50 + (int) ((colH >>> 8) & 63);
                int top = base + (int) Math.round(5.0D * Math.sin(z / 37.0D + (colH & 255)));
                return new Span(top - 3, top, (int) ((segH >>> 40) % 3));
            }
        }

        // Single floating slabs.
        if (((h >>> 4) & 7) == 0) {
            int top = 20 + (int) ((h >>> 12) & 127);
            return new Span(top - 4, top, palette);
        }
        return null;
    }

    private static BlockState unfinishedState(int x, int y, int z) {
        Span span = unfinishedSpan(x, z);
        if (span == null || y < span.bottom() || y > span.top()) return null;
        int depth = span.top() - y;
        switch (span.palette()) {
            case 1: // scaffold: planks over old stone brick
                return (depth < 2 ? Blocks.SPRUCE_PLANKS : Blocks.STONE_BRICKS).defaultBlockState();
            case 2: // blueprint: pale and unfinished
                if (depth < 1) return Blocks.SMOOTH_QUARTZ.defaultBlockState();
                return (depth < 3 ? Blocks.WHITE_CONCRETE : Blocks.STONE).defaultBlockState();
            default: // ordinary ground
                if (depth == 0) return Blocks.GRASS_BLOCK.defaultBlockState();
                return (depth < 4 ? Blocks.DIRT : Blocks.STONE).defaultBlockState();
        }
    }

    private static boolean hasWall(int cx, int cz, int salt) {
        return Math.floorMod(mix(cx, cz, salt), 3L) != 0L;
    }

    private static BlockState hallwayState(int x, int y, int z) {
        if (y == MIN_Y) return Blocks.BEDROCK.defaultBlockState();
        if (y < HALL_FLOOR - 1) return Blocks.STONE.defaultBlockState();
        if (y <= HALL_FLOOR) return Blocks.BROWN_TERRACOTTA.defaultBlockState();

        int lx = x & 15;
        int lz = z & 15;
        if (y == HALL_CEIL) {
            boolean light = (lx % 8 == 3 || lx % 8 == 4) && (lz % 8 == 3 || lz % 8 == 4);
            return (light ? Blocks.GLOWSTONE : Blocks.SMOOTH_SANDSTONE).defaultBlockState();
        }
        if (y > HALL_CEIL) return null;

        int cx = x >> 4;
        int cz = z >> 4;
        boolean pillar = lx < 2 && lz < 2;
        boolean wallW = lx == 0 && hasWall(cx, cz, 11) && !(lz >= 5 && lz <= 10);
        boolean wallN = lz == 0 && hasWall(cx, cz, 12) && !(lx >= 5 && lx <= 10);
        if (pillar) return Blocks.CUT_SANDSTONE.defaultBlockState();
        if (wallW || wallN) {
            return (y == HALL_FLOOR + 1 ? Blocks.SPRUCE_PLANKS : Blocks.SMOOTH_SANDSTONE).defaultBlockState();
        }
        return furniture(cx, cz, lx, y, lz);
    }

    /** One room in seventeen: a living room. The television is showing static. */
    private static BlockState furniture(int cx, int cz, int lx, int y, int lz) {
        if (Math.floorMod(mix(cx, cz, 31), 17L) != 0L) return null;

        if (lz == 2 && lx >= 5 && lx <= 10 && y >= 66 && y <= 68) {
            boolean white = Math.floorMod(mix(lx, y, cx * 7L + cz), 2L) == 0L;
            return (white ? Blocks.WHITE_CONCRETE : Blocks.BLACK_CONCRETE).defaultBlockState();
        }
        if (y == HALL_FLOOR + 1) {
            if (lz == 12 && lx >= 5 && lx <= 10) {
                return Blocks.DARK_OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.SOUTH);
            }
            if (lx == 7 && lz == 8) return Blocks.SPRUCE_FENCE.defaultBlockState();
            if (lx == 11 && lz == 4) return Blocks.OAK_FENCE.defaultBlockState();
            if (lx >= 3 && lx <= 12 && lz >= 3 && lz <= 11) return Blocks.RED_CARPET.defaultBlockState();
        }
        if (y == HALL_FLOOR + 2) {
            if (lx == 7 && lz == 8) return Blocks.SPRUCE_PRESSURE_PLATE.defaultBlockState();
            if (lx == 11 && lz == 4) return Blocks.LANTERN.defaultBlockState();
        }
        return null;
    }

    // ---------------------------------------------------------------- drowned

    private static int drownedFloor(int x, int z) {
        double h = -12.0D
                + 12.0D * Math.sin(x * 0.031D) * Math.sin(z * 0.027D)
                + 6.0D * Math.sin(x * 0.07D + z * 0.05D)
                + 4.0D * Math.cos(z * 0.11D - x * 0.03D);
        int floor = (int) Math.round(h);

        long hh = mix(x >> 4, z >> 4, 21);
        if ((hh & 31) == 0) {
            int dx = (x & 15) - 8;
            int dz = (z & 15) - 8;
            int r2 = dx * dx + dz * dz;
            if (r2 <= 16 + (int) ((hh >>> 8) & 15)) {
                floor = Math.max(floor, DROWN_SEA + 4 + (int) ((hh >>> 16) & 7) - r2 / 4);
            }
        }
        return floor;
    }

    private static BlockState drownedState(int x, int y, int z) {
        if (y == MIN_Y) return Blocks.BEDROCK.defaultBlockState();
        int floor = drownedFloor(x, z);
        if (y <= floor) {
            int depth = floor - y;
            if (y < -40) return Blocks.DEEPSLATE.defaultBlockState();
            if (depth <= 2) return (floor > DROWN_SEA ? Blocks.MOSSY_COBBLESTONE : Blocks.GRAVEL).defaultBlockState();
            return Blocks.STONE.defaultBlockState();
        }
        if (y <= DROWN_SEA) return Blocks.WATER.defaultBlockState();
        return null;
    }

    // ----------------------------------------------------------------- backup

    private static int backupHeight(int x, int z) {
        return 62 + (int) Math.round(3.0D * Math.sin(x * 0.02D) + 3.0D * Math.cos(z * 0.02D));
    }

    private static BlockState backupState(int x, int y, int z) {
        if (y == MIN_Y) return Blocks.BEDROCK.defaultBlockState();
        int h = backupHeight(x, z);
        if (y < h - 3) return Blocks.STONE.defaultBlockState();
        if (y < h) return Blocks.DIRT.defaultBlockState();
        if (y == h) return Blocks.GRASS_BLOCK.defaultBlockState();

        int lx = x & 15;
        int lz = z & 15;
        int dx = lx - 8;
        int dz = lz - 8;
        int up = y - h;

        // The same tree in every chunk, dead centre.
        if (dx == 0 && dz == 0 && up >= 1 && up <= 4) return Blocks.OAK_LOG.defaultBlockState();
        BlockState leaves = Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        if ((up == 3 || up == 4) && Math.abs(dx) <= 2 && Math.abs(dz) <= 2
                && !(Math.abs(dx) == 2 && Math.abs(dz) == 2) && !(dx == 0 && dz == 0)) return leaves;
        if (up == 5 && Math.abs(dx) <= 1 && Math.abs(dz) <= 1) return leaves;
        if (up == 6 && dx == 0 && dz == 0) return leaves;

        // Flowers and grass on a rigid grid, clear of the tree.
        if (up == 1 && !(Math.abs(dx) <= 2 && Math.abs(dz) <= 2)) {
            if (lx % 4 == 2 && lz % 4 == 0) {
                int pick = Math.floorMod((x >> 4) + (z >> 4), 3);
                if (pick == 0) return Blocks.POPPY.defaultBlockState();
                if (pick == 1) return Blocks.DANDELION.defaultBlockState();
                return Blocks.AZURE_BLUET.defaultBlockState();
            }
            if (lx % 4 == 0 && lz % 4 == 2) return Blocks.GRASS.defaultBlockState();
        }
        return null;
    }
}
