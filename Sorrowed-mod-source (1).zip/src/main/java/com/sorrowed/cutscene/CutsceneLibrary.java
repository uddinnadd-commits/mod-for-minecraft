package com.sorrowed.cutscene;

import java.util.HashMap;
import java.util.Map;

/** Every cutscene. ids "arrive_<dimension path>" play the first time you enter a dimension. */
public final class CutsceneLibrary {
    private CutsceneLibrary() {}

    private static final float P = Float.NaN;
    private static final Map<String, Cutscene> MAP = new HashMap<>();

    public static Cutscene get(String id) {
        return MAP.get(id);
    }

    private static void add(Cutscene c) {
        MAP.put(c.id(), c);
    }

    static {
        // First join: the camera looks you in the face, then tips up into the rain.
        add(Cutscene.builder("awakening", 230).blendOut(30).fade(14, 0, 0)
                .key(0, 0, 3.4, 1.7, 180, 0, 50)
                .key(70, 0, 4.2, 2.0, 180, -4, 52)
                .key(135, 0, 2.2, 0.9, 180, -70, 85)
                .key(195, 0, 0, 1.62, 0, P, 70)
                .caption(14, "...it's raining.")
                .caption(85, "That's wrong. It was clear a second ago.")
                .caption(155, "This was {friend}'s world.")
                .cue(0, "minecraft:weather.rain", 1.0F, 1.0F)
                .build());

        // The Unfinished: pull up and away to see how little is holding it together.
        add(Cutscene.builder("arrive_the_unfinished", 290).blendOut(30).fade(10, 0, 0)
                .key(0, 0, 0, 1.62, 0, P, 70)
                .key(55, 0, -3, 9, 0, 12, 80)
                .key(125, 0, -10, 30, 25, 25, 92)
                .key(195, 0, -10, 34, -30, 28, 92)
                .key(255, 0, -3, 8, 0, 8, 75)
                .caption(25, "No rain.")
                .caption(100, "Just... nothing. All of it hanging in the light.")
                .caption(195, "Every piece is one chunk wide. He measured it, then he stopped.")
                .cue(120, "minecraft:block.beacon.ambient", 0.5F, 0.6F)
                .build());

        // The Hush: a slow circle around you that ends with the camera standing behind you.
        add(Cutscene.builder("arrive_the_hush", 250).blendOut(25).fade(15, 0, 0)
                .orbit(0, 145, 3.6, 2.2, 0, 180, 1.0, 62, 14)
                .key(195, 0, 0, 1.62, 360, P, 70)
                .caption(20, "Why is it so quiet? The rain should be louder.")
                .caption(105, "I don't think this was him. Something else made this.")
                .caption(175, "Don't look back.")
                .cue(0, "minecraft:ambient.cave", 0.8F, 1.0F)
                .cue(150, "minecraft:entity.warden.heartbeat", 0.9F, 1.0F)
                .build());

        // The Drowned Hall: sink beside the platform and look down into it.
        add(Cutscene.builder("arrive_the_drowned", 270).blendOut(30).fade(10, 0, 0)
                .key(0, 0, 0, 1.62, 0, P, 70)
                .key(50, 5, 0, -2.5, 0, 20, 75)
                .key(120, 6, 1, -14, 0, 55, 85)
                .key(195, 6, 1, -24, -30, 70, 90)
                .key(245, 4, 0, -1, 0, 15, 72)
                .caption(25, "Everything's heavy. Even the dark is wet.")
                .caption(115, "There's a house down there. It still has air in it.")
                .caption(195, "I can still hear the rain. Even down here.")
                .cue(8, "minecraft:ambient.underwater.enter", 0.8F, 1.0F)
                .build());

        // The Hallway: a dolly zoom. The corridor stretches while you stand still.
        add(Cutscene.builder("arrive_the_hallway", 270).blendOut(30).fade(12, 0, 0)
                .key(0, 0, 0, 1.62, 0, P, 70, 0)
                .key(110, 0, -6, 1.62, 0, 0, 38, 0)
                .key(175, 0, -6, 1.62, 0, 0, 38, 2)
                .key(235, 0, 0, 1.62, 0, P, 70, 0)
                .caption(15, "I know this carpet.")
                .caption(100, "It's the hallway from his old house. It just never ends.")
                .caption(180, "It stretches when I look at it.")
                .cue(0, "minecraft:block.conduit.ambient", 0.7F, 0.8F)
                .build());

        // The Backup: sunlight, a lazy orbit, and one thing wrong.
        add(Cutscene.builder("arrive_the_backup", 270).blendOut(30).fade(20, 0, 0)
                .orbit(0, 205, 5.0, 2.6, 0, 360, 1.0, 58, 20)
                .key(245, 0, 0, 1.62, 360, P, 70)
                .caption(20, "It's perfect.")
                .caption(100, "Nothing here is moving. Not even the grass.")
                .caption(175, "Even the clouds are holding still.")
                .build());

        // The grave (anchored on the stone): circle it once.
        add(Cutscene.builder("grave", 300).blendOut(30).fade(8, 0, 0)
                .orbit(0, 235, 4.5, 2.4, 30, 250, 0.8, 55, 18)
                .caption(30, "A stone with no name on it.")
                .caption(110, "He wouldn't have needed one.")
                .caption(190, "{friend}. I came back.")
                .cue(200, "minecraft:block.bell.use", 0.4F, 0.6F)
                .build());

        // An event: the camera turns you around to look at the door that was not there.
        add(Cutscene.builder("door_behind", 175).blendOut(30)
                .key(0, 0, 0, 1.62, 0, P, 70)
                .key(45, 0, 0, 1.62, 180, 2, 62)
                .key(115, 0, 0, 1.62, 180, 2, 48)
                .caption(55, "That door wasn't there a minute ago.")
                .cue(5, "minecraft:entity.warden.heartbeat", 0.9F, 1.0F)
                .cue(45, "minecraft:entity.warden.heartbeat", 1.0F, 1.0F)
                .build());

        // Sorrow reaches 100: the world tilts, drops, and goes dark.
        add(Cutscene.builder("breakdown", 220).blendOut(0).fade(0, 60, 50)
                .key(0, 0, 0, 1.62, 0, P, 70, 0)
                .key(50, 0, 0, 0.5, 0, 25, 45, 25)
                .key(110, 0, 0, 0.15, 15, 40, 30, 60)
                .key(170, 0, 0, 0.1, 30, 50, 24, 85)
                .caption(20, "I can't tell if I'm remembering him or being remembered.")
                .caption(95, "stop looking at me")
                .caption(150, "{friend}?")
                .cue(0, "minecraft:entity.warden.heartbeat", 1.0F, 0.9F)
                .cue(60, "minecraft:entity.elder_guardian.curse", 0.5F, 0.7F)
                .build());
    }
}
