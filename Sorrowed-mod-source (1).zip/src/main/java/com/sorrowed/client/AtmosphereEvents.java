package com.sorrowed.client;

import com.sorrowed.Sorrowed;
import com.sorrowed.registry.Dimensions;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FogType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Per-dimension fog: the Hush closes in, the Hallway hazes yellow, the Drowned Hall is murk, the Backup is bright. */
@Mod.EventBusSubscriber(modid = Sorrowed.MODID, value = Dist.CLIENT)
public class AtmosphereEvents {
    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        ResourceKey<Level> dim = mc.level.dimension();
        FogType type = event.getType();

        if (dim.equals(Dimensions.HUSH) && type == FogType.NONE) {
            event.setNearPlaneDistance(0.0F);
            event.setFarPlaneDistance(40.0F);
            event.setCanceled(true);
        } else if (dim.equals(Dimensions.HALLWAY) && type == FogType.NONE) {
            event.setNearPlaneDistance(16.0F);
            event.setFarPlaneDistance(72.0F);
            event.setCanceled(true);
        } else if (dim.equals(Dimensions.DROWNED)) {
            if (type == FogType.NONE) {
                event.setNearPlaneDistance(0.0F);
                event.setFarPlaneDistance(110.0F);
                event.setCanceled(true);
            } else if (type == FogType.WATER) {
                event.setNearPlaneDistance(0.0F);
                event.setFarPlaneDistance(28.0F);
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        ResourceKey<Level> dim = mc.level.dimension();
        if (dim.equals(Dimensions.HUSH)) {
            set(event, 0.03F, 0.05F, 0.07F);
        } else if (dim.equals(Dimensions.HALLWAY)) {
            set(event, 0.52F, 0.46F, 0.16F);
        } else if (dim.equals(Dimensions.DROWNED)) {
            set(event, 0.02F, 0.18F, 0.20F);
        } else if (dim.equals(Dimensions.BACKUP)) {
            set(event, 1.0F, 0.96F, 0.85F);
        }
    }

    private static void set(ViewportEvent.ComputeFogColor event, float r, float g, float b) {
        event.setRed(r);
        event.setGreen(g);
        event.setBlue(b);
    }
}
