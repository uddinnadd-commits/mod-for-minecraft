package com.sorrowed.registry;

import com.sorrowed.Sorrowed;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Sorrowed.MODID);

    public static final RegistryObject<Item> RAIN_TEAR = ITEMS.register("rain_tear",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> UNFINISHED_DOOR = ITEMS.register("unfinished_door",
            () -> new BlockItem(ModBlocks.UNFINISHED_DOOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> HUSH_DOOR = ITEMS.register("hush_door",
            () -> new BlockItem(ModBlocks.HUSH_DOOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> DROWNED_DOOR = ITEMS.register("drowned_door",
            () -> new BlockItem(ModBlocks.DROWNED_DOOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> HALLWAY_DOOR = ITEMS.register("hallway_door",
            () -> new BlockItem(ModBlocks.HALLWAY_DOOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> BACKUP_DOOR = ITEMS.register("backup_door",
            () -> new BlockItem(ModBlocks.BACKUP_DOOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> GRAVE_MARKER = ITEMS.register("grave_marker",
            () -> new BlockItem(ModBlocks.GRAVE_MARKER.get(), new Item.Properties()));

    public static final RegistryObject<Item> ECHO_SPAWN_EGG = ITEMS.register("echo_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ECHO, 0xC9D6E0, 0x4A5668, new Item.Properties()));
    public static final RegistryObject<Item> HOLLOW_SPAWN_EGG = ITEMS.register("hollow_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.HOLLOW, 0x16161C, 0x6E7A8C, new Item.Properties()));
    public static final RegistryObject<Item> LISTENER_SPAWN_EGG = ITEMS.register("listener_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.LISTENER, 0xAAAAB0, 0x202024, new Item.Properties()));
    public static final RegistryObject<Item> MASON_SPAWN_EGG = ITEMS.register("mason_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MASON, 0x6E4C2C, 0xC8A082, new Item.Properties()));
}
